# CALISTIRMAK ICIN
- Terminal uzerinden make yazarak derleyip calistirabilirsiniz.

# GRUP UYELERI
- Omama Kasem                  / No: B191210568
- Sümeyye Yaşar                / No: G191210037
- Gülay Demir                  / No: B191210084
- Manar Saad Sadeq Al-Doori    / No: G191210553

# DIZIN LISTESI
- bin: calistirilabilir dosyalarinin bulundugu klasor.
- include: .h (baslik) dosyalarnin bulundugu klasor.
- lib: .o (obje) dosyalarinin bulundugu klasor.
- src: .c (kaynak) dosyalarinin bulundugu klasor.

# KARSLASTIGIMIZ ZORLUKLAR
-Linux isletim sistemi kurmak ve calıstırmak.

# KAYNAK
- [Stackoverflow](https://www.stackoverflow.com)
- [Askubuntu](https://askubuntu.com/)

